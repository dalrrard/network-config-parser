"""Tests for ncp."""
