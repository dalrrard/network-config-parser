# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ncp', 'ncp.helpers', 'ncp.ios', 'tests']

package_data = \
{'': ['*'], 'tests': ['data/*']}

install_requires = \
['networkx>=2.6.3,<3.0.0']

setup_kwargs = {
    'name': 'ncp',
    'version': '0.1.0',
    'description': 'Parse network device configuration files',
    'long_description': '# network-config-parser\n',
    'author': 'Dalton Rardin',
    'author_email': 'dalton@daltonrardin.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/dalrrard/network-config-parser',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
