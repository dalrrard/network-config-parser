"""IOS package."""
from .parser import IOSConfig

__all__ = ["IOSConfig"]
